import { theme } from '@drivx/design-tokens';

/** Keep the customer app on DrivX's shared white and blue brand theme. */
export const customerTheme = theme;
